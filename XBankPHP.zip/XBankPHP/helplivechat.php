
<div id="ClientDiv" style='padding-top:25px; font-weight: bold; display:none;'>
    <span >If you have personal questions, you could chat to one of our admin's: </span>
    <div>
        <button id='LiveChatButton' style='background-color:yellow; color:blue;' onclick="CreateLiveChat()">Start livechat</button>
    </div>
</div>


<div id="AdminDiv" style='padding-top:25px; font-weight: bold; display:none;'>
    <span>Available Live Chat(s): </span>
    <div id="ListLiveChatDiv">
        
    </div>
</div>





